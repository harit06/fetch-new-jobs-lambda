import os

def startlambda(event, context):
    print('Event: starting lambda function')
    print('Event: ending lambda function')